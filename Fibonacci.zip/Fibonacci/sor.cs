﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonacci
{
    internal class Sor
    {
        public int Sorszám {get;set;}

        public int Érték { get;set;}
    }
}
